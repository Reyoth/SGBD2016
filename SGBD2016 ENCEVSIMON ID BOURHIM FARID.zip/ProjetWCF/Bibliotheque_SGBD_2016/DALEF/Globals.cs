﻿namespace DALEF
{
    internal class Globals
    {
        public static string lecteurConnectionString =
                "metadata=res://*/ModelBiblioLecteur.csdl|res://*/ModelBiblioLecteur.ssdl|res://*/ModelBiblioLecteur.msl;provider=System.Data.SqlClient;provider connection string=&quot;data source=localhost;initial catalog=SGBD2016_Bibliotheque;user id=lecteur;password=lecteur;MultipleActiveResultSets=True;App=EntityFramework&quot;";
            //providerName="System.Data.EntityClient";
    }
}