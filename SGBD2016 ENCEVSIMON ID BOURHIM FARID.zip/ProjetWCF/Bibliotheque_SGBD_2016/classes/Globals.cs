﻿namespace DAL
{
    internal class Globals
    {
        public static string DefaultConnectionString =
            "Data Source=.;Initial Catalog = SGBD2016_Bibliotheque; User ID = sa; Password=farid";
    }
}