﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DALADO
{
    public class Globals
    {
        public static string AdminBiblioConnectionString =
            "Data Source=localhost;Initial Catalog = SGBD2016_Bibliotheque; User ID = adminBiblio; Password=adminBiblio";
        //"Data Source=localhost;Initial Catalog = SGBD2016_Bibliotheque; User ID = sa; Password=sa";
        public static string LecteurConnectionString =
            "Data Source=localhost;Initial Catalog = SGBD2016_Bibliotheque; User ID = lecteur; Password=letceur";

    }
}
